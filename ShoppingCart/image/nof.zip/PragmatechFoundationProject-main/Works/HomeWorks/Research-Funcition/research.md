### Function declaration > 

- function
 1. nwmune yaz 
 2. arrow function > https://aarslantas.medium.com/arrow-function-nedir-f4ef50cda66c
 3. return suz mukun deyil.