# solution-way
- plan resim
- sclet hazirla 

- Boostrap qos --- https://getbootstrap.com/docs/5.1/getting-started/introduction/ 

- .box class yarat;

- click - https://www.w3schools.com/html/tryit.asp?filename=tryhtml_script_html

- clickleri nece sayaram --https://www.google.com/search?q=how+to+count+button+click+in+javascript&rlz=1C1CHWL_trAZ964AZ964&oq=how+to+click+count++javascript+&aqs=chrome.1.69i57j0i8i30l2j0i8i10i30.27895j0j7&sourceid=chrome&ie=UTF-8

- sayilan clickleri  a-ya bərabər et

- ```
        for (i=0;i=a;i++){
        div ementinin təkrak funksiyasi  
        }
```