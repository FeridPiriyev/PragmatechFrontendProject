# Arithmetic Operator

x=int(input())
y=int(input())

c=x+y
print("Cəm = ",c)

c=x-y;
print("Ferq = ",c)

c=x*y
print("Hasil = ",c)

c=x/y
print('Qismet',c)

c=x**y
print("Quvveti = ",c)

# Assignment Operators

a=5
print(a)

b=10
b+=5
print(b) 

d=25
d-=15
print(d)

e=40
e/=20
print(e)

