# Operatorlar

 - Arithmetic Operator
    - (+ >>> x+y)
    - (- >>> x-y)
    - (* >>> x*y)
    - (/ >>> x/y)
    - (** >>> x**y)


- Assignment Operators
    - (= >>> a=5)
    - (+= >>> b+=5)
    - (-= >>> d-=15)
    - (/= >>> e/=20)



