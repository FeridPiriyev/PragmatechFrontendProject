str='Proqramalaşdırma nə qədər çox şey bildiyinizlə yox, bildiyinizlə ortaya çıxardığınız işlərlə maraqlanır'
#str daxilində neçə xarakter olduğunu ekrana yazdırın

a=0
for elmet in str:
   a+=1 
print('Daxildə ki, element sayı',end='-')
print(a)



