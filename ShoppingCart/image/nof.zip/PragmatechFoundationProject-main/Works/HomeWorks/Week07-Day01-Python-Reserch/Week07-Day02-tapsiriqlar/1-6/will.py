strs='Proqramalaşdırma nə qədər çox şey bildiyinizlə yox, bildiyinizlə ortaya çıxardığınız işlərlə maraqlanır'

# str ni vergülə görə ayırıb iki string halına gətirin
# stringSearch(word) adında bir metod yazın. daxil edilən sözün mətnin içində olub olmadığını ekrana çap edən metod yazın



d=strs.split(',')

a=d[0]
b=d[1]

print(a)
print(b)

print(type(a))
print(type(b))

