stars="""Proqramalaşdırma nə qədər çox şey bildiyinizlə yox, bildiyinizlə ortaya 
çıxardığınız işlərlə maraqlanır"""

# str daxilindəki sözləri ayrı bir massiv içərisində toplayın
m=stars.split(' ')
print(m)