# DATA TYPE
## Python Data type
### Data tipi yoxlama metodu > type()

- String data type → str 
    - Mətin tipidir. _will.py > kod setri > 4_
    - Dəyişənə string dəyər atamak üçün > "" və ya '' ifadəsi dən istifadə edilir._will.py > kod setri > 2 ve 5_
    - Birdən çox sətirlik ifadə olduqda > """  """ və ya '''  ''' istifad' edilir. _will.py > kod setri > 8 ve 12_ 
    - digər dillərdən fərqli olaraq *Python* -da char data tipi yoxdur,bu səbəblə verilən string dəyərlərin hamsi 1 string dəyərdir onlara []- istifadə edərək çağırmaq olar. _will.py > kod setri > 14 ve 2_ 
- Rəqəmsal (Number) tiplər → int, float, complex 
    - int > Tam ədədlər üçün rəqəm tipidir  _will.py > kod setri > 19_ 
    - float > kəsir ədədlər _will.py > kod setri > 20 ve 21_ 
    - Complex > düsturlarin yazilmasinda istifadə edilir._will.py > kod setri > 22_

- Sıra (Sequence) tipleri → list, tuple, range
    - list > daxilində bir neçə dəyər saxlaya bilir.Məs:String,Number vs.bir list dəyəri yaratmaq üçün > [] yaz  _will.py > kod setri > 26 ve 27_
    - tuple > listlə demək olar eynidir sadəcə yazilan məumat dəyişdirilmir.bir tiple dəyəri yaratmaq üçün > () yaz _will.py > kod setri > 29 ve 32_

- Mapping tipi → dict
    - key  ve velue birgə olan bir dəyər tipidir.

- Boolean veri tipleri → bool
    - true and false deyerleri olan bir tip


