## Interpreter vs Compiler

### Interpreter vs Compiler izahi üçün restoran mətbəxi ilə izah edəcəm.
* Interpreter.
- Interpreter mətbəx. Bir restoran mətbəxi düşünün. İçəridə bir texniki-aşbaz var və müxtəlif yeməkləri bişirmək üçün  müxtəlif böyüklüdə aparatlar var. Məs:desert sfarişi verlir texniki-aşbaz gedir desertləri hazəlamaq üçün olan aparat önünə verilən sifarişə uyğun məlumatları aparata girərək   və s.
    - (Vaxt istifadəsi) Texniki-aşbaz göndərilən sifarişə  uyğun aparatları işə salır. Burada gözləmə vaxtları yanlız apartlarin işləmə müdətindədir.Təbii ki ona verilən sifarişləri ardıcıl olaraq və bir-bir  yerinə yetirir. 
    - (Eyni Axtekturada işləmə) İşlərin əsası aparatlar vastəsi ilə getdiyi üçün aparat qurulu bir mətməx olduqdan sonra texniki-aşbaz üçün fərqi yoxdur hardada və necə bir yerdə işlədiyinin. 
    - (Yaddaşda yer tutma məsələsi) Burada fikir verməli olduğumuz yer yazılan praqramin tutacağı yerdir yəni texniki-aşbaza verilən əmirlədir. İşləri apartalar gördüyü üçün verilən əmirlərdə kiçik və anlaşılandır. 