const fulname = 'MadWill'
const city = 'StarReaktor'
const age = 1998;

let a ;

a = `my namre ${fulname} I'am ${2021-age} year old and I live ${city} `

console.log(a);

a = `my namre ${fulname} I'am ${(2021-age>=18)?'over 18':'under 18'}  and I live ${city} `

console.log(a);