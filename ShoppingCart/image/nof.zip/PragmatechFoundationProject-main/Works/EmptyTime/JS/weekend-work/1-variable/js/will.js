// var ,let ,const

// var təyin olunduqdan sonra istənilən yerdə çağırla bilir


var b=2;
console.log(b)


// let ancaq özündən sonra çağırlanda təyin olunur
let a=5;

console.log(a)
a=9;
console.log(a)

let ad='star';
alert(ad);

// const bir dəyərə ancaq birdəfə dəyər atamağa içazə verir

const c=4;
console.log(c)

c=7;