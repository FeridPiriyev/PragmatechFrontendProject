const firstname = 'ahmed'
const age = 22;
const isStudent = true;



if (age === 22/*boolean deyer*/){
    console.log('great')
}


if ((isStudent == false)|| (age >=21 )){
    console.log('right')
}else{
    console.log('merhaa')
}


if ((age>=0)&&(age<=12)){
    console.log('balaca')
}else if((age>=13)&&(age<=19)){
    console.log('tinager')
}else if((age>=19)&&(age<=25)){
    console.log('yetiskin')
}