let tar = 'Mad'
tar +='Will'
console.log(tar);

// string
tar=tar.toUpperCase();// boyuk herfle hamsi
console.log(tar);

tar=tar.toLowerCase();// kicik herf
console.log(tar);

tar = tar.indexOf('w')// string deyer axtarma
console.log(tar);

tar = tar.substring(1,7)//yazi secme
console.log(tar);

tar = tar.slice(1,4)//yazi keib ciarma
console.log(tar);

tar = tar.replace('Mad','Dr')
console.log(tar);