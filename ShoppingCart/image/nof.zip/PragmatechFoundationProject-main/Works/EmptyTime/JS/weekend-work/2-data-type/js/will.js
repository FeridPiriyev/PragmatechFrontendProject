// deyişken tipler

// typeof deyesenin tipini tapir

// Primitive tip

 // String yazı dəyər
    let fristname='HauSoku no Haki'
    console.log(typeof fristname);

 // Number rəqəmlər toplusu dəyəri
    let age=15;
    console.log(typeof age)
    let pul=100.5;
    console.log(typeof pul)

 // Boolean iki dəyəri olan bir tip seçimlərdə olan dəyər
    let yang = true;
    let yin = false;
    console.log(typeof yang)
    console.log(typeof yin)

 // null 
    let para = null

    console.log(typeof para)


 // underfined
    let hayat;

    console.log(typeof hayat)
     
//  Reference tip

 // Array
    let will=['fighter','challenger']

    console.log(typeof will)

 // Object 

  let way = {
      will:'fighter',
      way:'learn'
  }

  console.log(typeof way,'-')

 // Funcition
    let hesab = function(){
        return 15
    }

    console.log(typeof hesab);



