import os

# print(os.name)


print(os.getcwd())

import sys

print(sys.version)

