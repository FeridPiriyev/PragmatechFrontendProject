a=input();
c=" Okey Adyos";
b=a+c
print(b)