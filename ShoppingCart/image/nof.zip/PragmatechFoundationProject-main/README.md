   
# Salahov Nofəl

## Haqqımda qısa məlumat

#### Tədrisə başladığım tarix : 23 İyun 2021
-  MyPortfolio design
    - [My Portfolio](https://nofelsalahov.herokuapp.com/)
    - MyPortfolio Front-end complate - 99%
    - MyPortfolio Back-end complate - 99%

#### Tədrisə bitirdiyim tarix : 15 Sentyabr 2021